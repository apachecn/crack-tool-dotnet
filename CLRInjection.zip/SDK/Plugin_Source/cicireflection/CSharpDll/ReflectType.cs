﻿using System;
using System.Collections.Generic;
using System.Text;
/*
 * http://www.chengchen.net
 * http://hi.baidu.com/tease/
 * by 程晨
 * 2008-06-01
 */
namespace CSharpDll
{
    public enum ReflectTypes
    {
        NAMESPACE,
        CLASS,
        METHOD,
        ENUM,
        SUBENUM,
        PROPERTY
    }
}
